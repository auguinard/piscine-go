#! /bin/bash

echo "Hello auguinard!"
